$(document).ready(function() {

	//title 화면
	$("#intro .next").on("click", () => {
		$("#ui").css({
				"background-image":"url(img/background.jpg)",
				"background-position":"center"
			});
	});
	$("#setting .back").on("click", () => {
		$("#ui").css({
				"background-image":"url(img/background.jpg)",
				"background-position":"center"
			});
	});
	$("#choice .back").on("click", () => {
		$("#ui").css({
				"background-image":"url(img/background.jpg)",
				"background-position":"center"
			});
	});

});